import { Component, OnInit } from '@angular/core';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';

@Component({
  selector: 'app-attendence',
  templateUrl: './attendence.component.html',
  styleUrls: ['./attendence.component.css']
})
export class AttendenceComponent implements OnInit {
  minDate: Date;

  constructor() {
    const currentYear = new Date().getFullYear();
    this.minDate = new Date;
  }

  ngOnInit(): void {
  }
  isAttendence = false;
  selectedValue = '';
  isHourSelected = false;


  Pselect = false;
  Aselect = false;
  Oselect = false;

Pchange(){
  this.Pselect = !this.Pselect;
}

Achange(){
  this.Aselect = !this.Aselect;
}

Ochange(){
  this.Oselect = !this.Oselect;
}

  foods:any = [
    {value: '1', viewValue: '1'},
    {value: '2', viewValue: '2'},
    {value: '3', viewValue: '3'},
    {value: '4', viewValue: '4'},
    {value: '5', viewValue: '5'},
    {value: '6', viewValue: '6'},
    {value: '7', viewValue: '7'},
    {value: '8', viewValue: '8'},
  ];


  addEvent(type: string, event: MatDatepickerInputEvent<Date>) {
   this.isHourSelected = true;
  }

  myFilter = (d: Date | null): boolean => {
    const day = (d || new Date()).getDay();
    return day !== 0 && day !== 7;
  };

  hourSelect(val:any){
    console.log("selected");
    this.isAttendence = true;
  }
}
