import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-daywise',
  templateUrl: './daywise.component.html',
  styleUrls: ['./daywise.component.css']
})
export class DaywiseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
