import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-approval-rejection',
  templateUrl: './approval-rejection.component.html',
  styleUrls: ['./approval-rejection.component.css']
})
export class ApprovalRejectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
